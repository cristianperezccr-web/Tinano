
package com.impuestos.tarifas.service;

import java.math.BigDecimal;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

@Service
public class tarifaservice {
    @Value("${tarifa.valor-credito}")
    private BigDecimal valorCredito;
    @Value("${tarifa.iva}")
    private BigDecimal porcentajeIva;
    @Value("${tarifa.beca}")
    private BigDecimal porcentajeBeca;
    @Value("${tarifa.mora}")
    private BigDecimal porcentajeMora;
     public Liquidacion calcularLiquidacion(String estudiante, int creditos,
                                           boolean becado, boolean enMora){
     if (creditos <= 0){
         throw new IllegalArgumentException("Los créditos deben ser mayores a 0");                 }
     }
}
